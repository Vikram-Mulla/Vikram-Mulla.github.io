var express = require('express');
var router = express.Router();
var tripsController = require('../controllers/trips'); // Import controller

// Debugging log to check if this file is being used
console.log("`trips.js` route file is loaded!");

// GET /api/trips - Get all trips
router.get('/', (req, res) => {
    console.log("GET /api/trips was called!"); // Debugging log
    tripsController.tripsList(req, res);
});

// GET /api/trips/:code - Get a specific trip by its code
router.get('/:code', (req, res) => {
    console.log(`GET /api/trips/${req.params.code} was called!`); // Debugging log
    tripsController.tripsFindByCode(req, res);
});

// POST create a new trip
router.post('/', (req, res) => {
    console.log("POST /api/trips called", req.body);
    tripsController.tripsAddTrip(req, res);
});

// PUT update an existing trip by code
router.put('/:code', (req, res) => {
    console.log(`PUT /api/trips/${req.params.code} was called!`, req.body); // Debugging log
    tripsController.tripsUpdateTrip(req, res);
});

module.exports = router; // Ensure only `router` is exported
