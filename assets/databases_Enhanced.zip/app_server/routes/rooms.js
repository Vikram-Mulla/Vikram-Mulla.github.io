var express = require('express');
var router = express.Router();
var roomsController = require('../controllers/rooms');

router.get('/', roomsController.roomsPage);

module.exports = router;
