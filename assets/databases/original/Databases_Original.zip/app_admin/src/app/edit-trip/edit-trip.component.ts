import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';

import { TripDataService } from '../services/trip-data.service';
import { Trip } from '../models/trip';

@Component({
  selector: 'app-edit-trip',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './edit-trip.component.html',
  styleUrls: ['./edit-trip.component.css']
})
export class EditTripComponent implements OnInit {

  editForm!: FormGroup;
  submitted = false;
  tripCode: string = '';

  constructor(
    private formBuilder: FormBuilder,
    private tripDataService: TripDataService,
    private router: Router
  ) { }

  ngOnInit() {
    this.tripCode = localStorage.getItem('tripCode') || '';
    if (!this.tripCode) {
      alert('Invalid action.');
      this.router.navigate(['']);
      return;
    }

    this.editForm = this.formBuilder.group({
      code: [{ value: '', disabled: true }, Validators.required],
      name: ['', Validators.required],
      length: ['', Validators.required],
      start: ['', Validators.required],
      resort: ['', Validators.required],
      perPerson: ['', Validators.required],
      image: ['', Validators.required],
      description: ['', Validators.required]
    });

    this.tripDataService.getTrip(this.tripCode)
      .subscribe({
        next: (trip: Trip) => this.editForm.patchValue(trip),
        error: (error: any) => console.error('Error: ' + error)
      });
  }

  get f() {
    return this.editForm.controls;
  }

  onSubmit() {
    this.submitted = true;
    if (this.editForm.valid) {
      const updatedTrip = this.editForm.getRawValue() as Trip;
      updatedTrip.code = this.tripCode;
      this.tripDataService.updateTrip(updatedTrip)
        .subscribe({
          next: () => this.router.navigate(['']),
          error: (error: any) => console.error('Error: ' + error)
        });
    }
  }
}
