import { Injectable, inject } from '@angular/core';
import { HttpRequest, HttpHandlerFn, HttpInterceptorFn } from '@angular/common/http';
import { AuthenticationService } from '../services/authentication.service';

export const authInterceptProvider: HttpInterceptorFn = (request: HttpRequest<any>, next: HttpHandlerFn) => {
    // Use Angular's inject function to properly get the service instance
    const authenticationService = inject(AuthenticationService);
    const isAuthAPI = request.url.startsWith('login') || request.url.startsWith('register');

    if (authenticationService.isLoggedIn() && !isAuthAPI) {
        const token = authenticationService.getToken();
        const authReq = request.clone({
            setHeaders: { Authorization: `Bearer ${token}` }
        });
        return next(authReq);
    }
    return next(request);
};
