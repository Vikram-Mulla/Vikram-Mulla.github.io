# Travlr Full Stack Application (Enhanced for Database - CS 499)

This project is a secure, full stack travel planner app built with the MERN stack:
- **MongoDB** (Database)
- **Express.js** (Server)
- **Angular** (Admin SPA)
- **Node.js** (Runtime)

---

## ✅ Enhancements in This Version

### 🔐 Security & Authentication
- **JWT Authentication**: Protected routes now require valid JSON Web Tokens.
- **Role-Based Access Control**: Routes distinguish between `user` and `admin` roles for enhanced permission control.
- **Mongoose Validation**: Models include required fields, maxLength checks, and type enforcement.
- **Input Sanitization**: Basic validation and error handling for all API endpoints.

### 🧩 API and Database
- All API endpoints are now protected by auth middleware.
- Enhanced models enforce stricter schema definitions.
- New routes for admin-only functions like creating/editing trips.
- Secure error handling middleware logs and prevents info leaks.

---

## 🚀 How to Run This Project

### 1. Install Dependencies
From the project root:
```bash
cd Travlr
npm install
```

Also install client/admin packages:
```bash
cd app_admin
npm install
```

### 2. Configure MongoDB
Create a `.env` file in the root folder with your MongoDB URI:
```env
DB_URI=mongodb://localhost:27017/travlr
JWT_SECRET=your_jwt_secret_here
```

### 3. Start the Server and Client
```bash
# From project root
npm start           # Starts Express API

# In a new terminal
cd app_admin
ng serve            # Starts Angular admin app
```

Then visit:
```
http://localhost:4200
```

---

## 📄 Example Admin JWT
You can test protected routes with an admin-level JWT token:
```
Authorization: Bearer <your-jwt-here>
```

---

© 2025 - Database Enhancement for SNHU CS-499 Capstone
