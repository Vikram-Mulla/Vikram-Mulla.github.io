const jwt = require('jsonwebtoken'); // Enable JSON Web Tokens
const express = require("express"); // Express app
const router = express.Router(); // Router logic

// Import controllers
const tripsController = require("../controllers/trips");
const authController = require('../controllers/authentication');

// Middleware to authenticate JWTs
function authenticateJWT(req, res, next) {
    const authHeader = req.headers['authorization'];
    
    if (!authHeader) {
        console.log('Auth Header Required but NOT PRESENT!');
        return res.sendStatus(401);
    }

    const token = authHeader.split(' ')[1];
    if (!token) {
        console.log('Null Bearer Token');
        return res.sendStatus(401);
    }

    jwt.verify(token, process.env.JWT_SECRET, (err, verified) => {
        if (err) {
            console.log('Token Validation Error:', err.message);
            return res.status(401).json('Token Validation Error!');
        }
        req.auth = verified; // Set the auth param to the decoded object
        next();
    });
}

// Routes for Authentication
router.route("/register").post(authController.register);
router.route("/login").post(authController.login);

// Routes for Trips (with JWT Authentication)
router
    .route("/trips")
    .get(tripsController.tripsList) // GET: Retrieve all trips
    .post(authenticateJWT, tripsController.tripsAddTrip); // POST: Add a new trip (requires auth)

router
    .route('/trips/:tripCode')
    .get(tripsController.tripsFindByCode) // GET: Retrieve a specific trip by code
    .put(authenticateJWT, tripsController.tripsUpdateTrip); // PUT: Update a trip (requires auth)

module.exports = router;
