const Trip = require('../models/travlr'); // Import the Trip model

// Get all trips
const tripsList = async (req, res) => {
    try {
        console.log("API hit: GET /api/trips");
        const trips = await Trip.find({}).exec();
        if (!trips || trips.length === 0) {
            return res.status(404).json({ message: "No trips found" });
        }
        res.status(200).json(trips);
    } catch (err) {
        console.error("Database error:", err);
        res.status(500).json({ message: "Database error", error: err });
    }
};

// Get a single trip by code
const tripsFindByCode = async (req, res) => {
    try {
        console.log(`Looking up trip with code: ${req.params.code}`);
        const trip = await Trip.findOne({ code: req.params.code }).exec();
        if (!trip) {
            console.log("Trip not found in database!");
            return res.status(404).json({ message: "Trip not found" });
        }
        console.log("Trip found:", trip);
        res.status(200).json(trip);
    } catch (err) {
        console.error("Database error:", err);
        res.status(500).json({ message: "Database error", error: err });
    }
};

// POST: /trips - Adds a new Trip
// Regerdless of outcome, response must include HTML status code
// and JSON message to the requesting cient
const tripsAddTrip = async(req, res) => {
    const newTrip = new Trip({
        code: req.body.code,
        name: req.body.name,
        length: req.body.length,
        start: req.body.start,
        resort: req.body.resort,
        perPerson: req.body.perPerson,
        image: req.body.image,
        description: req.body.description
    });

    const q = await newTrip.save();

        if(!q)
        { // Database returned no data
            return res
                .status(400)
                .json(err);
        } else { // Return new trip
            return res
                .status(201)
                .json(q);
        }
}

// PUT: /trips/:tripCode - Adds a new Trip
// Regardless of outcome, response must include HTML status code
// and JSON message to the requesting client
const tripsUpdateTrip = async (req, res) => {
    try {
        console.log(`PUT request received for trip code: ${req.params.code}`);
        console.log("Request Body:", req.body);

        const updatedTrip = await Trip.findOneAndUpdate(
            { code: req.params.code },
            { $set: req.body },
            { new: true }
        );

        if (!updatedTrip) {
            console.log(" Trip not found in database.");
            return res.status(404).json({ message: "Trip not found" });
        }

        console.log(" Trip updated successfully:", updatedTrip);
        res.status(201).json(updatedTrip);
    } catch (error) {
        console.error(" Error updating trip:", error);
        res.status(500).json({ error: "Database error while updating trip" });
    }
};

module.exports = {
    tripsList,
    tripsFindByCode,
    tripsAddTrip,
    tripsUpdateTrip
 };
