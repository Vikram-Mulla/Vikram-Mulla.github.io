const mongoose = require('mongoose');
const User = require('../models/user');
const passport = require('passport');

// Controller for User Registration
const register = async (req, res) => {
  if (!req.body.email || !req.body.name || !req.body.password) {
    return res.status(400).json({ message: 'All fields are required' });
  }

  // Check if the user already exists
  const existingUser = await User.findOne({ email: req.body.email });
  if (existingUser) {
    return res.status(400).json({ message: 'Email is already in use' });
  }

  try {
    // Create a new user instance
    const user = new User({
      email: req.body.email,
      name: req.body.name
    });

    // Set the user's password (hashing it)
    user.setPassword(req.body.password);

    // Save the user to MongoDB
    await user.save();

    // Generate a JWT Token for the new user
    const token = user.generateJWT();

    return res.status(201).json({ token });
  } catch (error) {
    return res.status(500).json({ message: 'Error registering user', error });
  }
};

// Controller for User Login
const login = (req, res) => {
  if (!req.body.email || !req.body.password) {
    return res.status(400).json({ message: 'All fields required' });
  }

  // Delegate authentication to passport module
  passport.authenticate('local', (err, user, info) => {
    if (err) {
      return res.status(404).json(err); // Error in authentication process
    }

    if (user) { 
      // Authentication succeeded, generate JWT and return to caller
      const token = user.generateJWT();
      return res.status(200).json({ token, message: 'Login successful' });
    } else { 
      // Authentication failed
      return res.status(401).json(info);
    }
  })(req, res);
};

// Export the Controller
module.exports = { register, login };
