// app_server/routes/meals.js

var express = require('express');
var fs = require('fs');
var path = require('path');
var router = express.Router();

// Read meals data (you may want to load it dynamically or from a database in real applications)
var mealsData = JSON.parse(fs.readFileSync(path.join(__dirname, '..', '..', 'data', 'meals.json'), 'utf8'));

// Route to render the list of meals
router.get('/', function(req, res) {
    res.render('meals', { meals: mealsData });
});

// Route to render individual meal details
router.get('/:id', function(req, res) {
    var meal = mealsData.find(m => m.id === req.params.id);
    if (meal) {
        res.render('meal-details', { meal: meal });
    } else {
        res.status(404).send("Meal not found");
    }
});

module.exports = router;
