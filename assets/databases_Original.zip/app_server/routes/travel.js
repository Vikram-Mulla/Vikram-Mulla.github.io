var express = require('express');
var router = express.Router();
var controller = require('../controllers/travel');  // Import the controller

/* GET travel page. */
router.get('/', controller.travel);

// Route for displaying a single trip's details
router.get('/:code', controller.travel);

module.exports = router;
